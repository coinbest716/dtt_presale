# ownership-contract
smart contracts for ownership platform
